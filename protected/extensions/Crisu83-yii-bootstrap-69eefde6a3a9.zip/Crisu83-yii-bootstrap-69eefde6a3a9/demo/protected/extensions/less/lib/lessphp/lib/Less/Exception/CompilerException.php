<?php

namespace Less\Exception;

class CompilerException extends \Exception
{

}