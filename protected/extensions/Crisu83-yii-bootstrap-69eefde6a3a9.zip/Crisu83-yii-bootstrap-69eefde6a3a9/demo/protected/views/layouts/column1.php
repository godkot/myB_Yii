<?php $this->beginContent('//layouts/main'); ?>

<?php echo $content; ?>

<?php $this->endContent(); ?>