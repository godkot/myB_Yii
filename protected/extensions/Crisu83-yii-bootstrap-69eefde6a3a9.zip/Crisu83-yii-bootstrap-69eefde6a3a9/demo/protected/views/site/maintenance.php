<?php $this->pageTitle = array('We are undergoing maintenance', Yii::app()->params['appTitle']); ?>

<div class="hero-unit">
	<h1>We are undergoing maintenance...</h1>
	<p>...at the moment and will be back shortly. Sorry for the inconvenience.</p>
</div>