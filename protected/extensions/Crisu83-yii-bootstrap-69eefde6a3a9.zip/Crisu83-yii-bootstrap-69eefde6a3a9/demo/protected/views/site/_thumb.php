<li class="span3">
	<a href="#" class="thumbnail" rel="tooltip" data-title="Tooltip">
		<img src="http://placehold.it/280x180" alt="">
	</a>
</li>