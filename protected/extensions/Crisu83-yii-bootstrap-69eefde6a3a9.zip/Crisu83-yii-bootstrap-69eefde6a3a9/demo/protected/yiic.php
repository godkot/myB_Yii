<?php

// change the following paths if necessary
$yiic=dirname(__FILE__).'/../../../../yii-1.1.9.r3527/framework/yiic.php';
$config=dirname(__FILE__).'/config/console.php';

require_once($yiic);
